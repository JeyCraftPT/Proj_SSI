from src.frontend.ui import CryptoVaultApp

if __name__ == "__main__":
    app = CryptoVaultApp()
    app.run()
