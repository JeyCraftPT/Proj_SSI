import sqlite3
import os


os.makedirs("data", exist_ok=True)
path_DB = "data/users.db"


def connectDB():
    return sqlite3.connect(path_DB)


def initializeDB():
    connection = connectDB()
    cursor = connection.cursor()

    # Tabela "users":
    # - id: id de cada user (chave primária)
    # - username: nome do user (único)
    # - salt: valor único e aleatório usado na derivação da password 
    # - id_val: id da autenticação usado no processo de login 
    # - iterations: número de iterações utilizadas para derivar a password
    # - last_nonce: último valor de nonce utilizado no processo de login 
    # - passwordD_hash: Hash da password derivada 
    cursor.execute(""" CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        salt TEXT UNIQUE NOT NULL,
                        id_val INTEGER NOT NULL,
                        iterations INTEGER NOT NULL,
                        last_nonce BLOB NOT NULL,
                        passwordD_hash TEXT NOT NULL
                        );""")
    
    # Tabela "signatures" : 
    # - id: id de cada signature (chave primária)
    # - user_id: id do user que gerou a signature (chave estrangeira)
    # - public_key: chave pública para verificar a signature e associada ao user
    # - private_key_path: path de onde a chave privada do user está armazenada e que foi usada para criar a signature
    # - pk_name: nome associado à chave pública 
    # - signature: signature gerada através da chave privada
    cursor.execute(""" CREATE TABLE IF NOT EXISTS signatures (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        public_key TEXT NOT NULL,
                        private_key_path TEXT NOT NULL,
                        pk_name TEXT NOT NULL,
                        signature TEXT NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                        );""")

    # Tabela "enc_files" : 
    # - id: id do ficheiro cifrado (chave primária)
    # - user_id: id do user que gerou o ficheiro (chave estrangeira)
    # - filename: nome do ficheiro cifrado
    # - iv: iv utilizado para cifrar o ficheiro
    # - hmac: hmac criado para garantir a integridade e autenticidade dos dados no ficheiro (utilizado para verificar se o ficheiro foi alterado)
    # - file_path: path de onde está armazenado o ficheiro
    # - cipher_type: cifra utilizada para cifrar o ficheiro
    cursor.execute(""" CREATE TABLE IF NOT EXISTS enc_files (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        filename TEXT NOT NULL,
                        iv TEXT,
                        hmac TEXT,
                        file_path TEXT NOT NULL,
                        cipher_type TEXT NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users(id) 
                        );""")
    
    connection.commit()
    connection.close()